# bpmn-js starter

Try out our toolkit by downloading the [viewer](https://cdn.statically.io/gh/bpmn-io/bpmn-js-examples/main/starter/viewer.html) or [modeler](https://cdn.statically.io/gh/bpmn-io/bpmn-js-examples/main/starter/modeler.html) example.


[![viewer example screenshot](./viewer.png)](https://cdn.statically.io/gh/bpmn-io/bpmn-js-examples/main/starter/viewer.html)

_Screenshot of the [viewer example](https://cdn.statically.io/gh/bpmn-io/bpmn-js-examples/main/starter/viewer.html)._